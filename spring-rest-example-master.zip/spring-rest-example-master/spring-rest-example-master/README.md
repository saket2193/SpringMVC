spring-rest-example
===================

Simple Spring Rest MVC Example to demonstrate a simple bookservice example which allows Get and Add of a book via
Rest EndPoints. This example can produce JSON or XML based on the Accept-Header of the client.

Project packaging is war file. To run this, deploy to an application container (such as Apache Tomcat)
