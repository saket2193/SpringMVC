package com.sample.controller;


import com.sample.domain.NameChange;
import com.sample.domain.NameChangeResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;
import javax.inject.Named;



@RestController
@RequestMapping("/name")
public class NameRestController {

    private Logger logger=LoggerFactory.getLogger(NameRestController.class);


    @RequestMapping(value = "/change",  method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    public NameChangeResponse addBook(@RequestBody NameChange namechange)
    {
    	//JSONObject jsonObject = new JSONObject();
    	return new NameChangeResponse();
    }
}
