package com.sample.domain;

public class NameChangeResponse {
    public String AcknowledgementNo;

    public NameChangeResponse() {
    	this.AcknowledgementNo = "AcknowledgementNo";
    }

    public NameChangeResponse(String AcknowledgementNo) {
        this.AcknowledgementNo = AcknowledgementNo;
    }

    
}
