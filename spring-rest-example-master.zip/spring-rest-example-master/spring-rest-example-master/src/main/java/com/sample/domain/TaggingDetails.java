package com.sample.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TaggingDetails {
	
	private final String iDoc;
	private final String ImageName;
	private final String ImageBinary;
	
	
	public TaggingDetails(@JsonProperty("iDoc") String iDoc, 
			  @JsonProperty("ImageName") String ImageName,
			  @JsonProperty("ImageBinary") String ImageBinary) {
		super();
		this.iDoc=iDoc;
		this.ImageName=ImageName;
		this.ImageBinary=ImageBinary;
		
	}


	public String getiDoc() {
		return iDoc;
	}


	public String getImageName() {
		return ImageName;
	}


	public String getImageBinary() {
		return ImageBinary;
	}

}
